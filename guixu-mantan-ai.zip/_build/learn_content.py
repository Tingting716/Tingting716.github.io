LESSONS = [
    {
        "key": "p1-ai-definition",
        "group": "基础与历史",
        "short": "人工智能是什么",
        "title": "人工智能是什么：定义、边界与分类",
        "chapter": "教材第 1 章 · 1.1",
        "minutes": 10,
        "tags": "定义 · 分类 · 能力边界",
        "dek": "人工智能不是一个单一的程序，而是一组让机器完成感知、学习、推理、决策与生成任务的方法。先厘清定义与分类，才不容易被名词带着走。",
        "body": """
          <h3>从任务理解 AI，而不是从“像不像人”理解</h3>
          <p>人工智能（Artificial Intelligence，AI）是研究和构建能够完成感知、推理、学习、规划、语言理解与生成等任务的计算系统。它没有一个人人同意的统一定义，因为这个领域从一开始就同时包含工程目标、认知科学与哲学争论。</p>
          <p>更实用的理解方式是看“系统能完成什么任务、需要什么数据、边界在哪里”。人工智能既可以是写死规则的专家系统，也可以是从数据中学习模式的机器学习模型。并非所有 AI 都依赖深度学习，更不是所有 AI 都会生成内容。</p>
          <h3>AI、机器学习、深度学习与生成式 AI</h3>
          <p>它们通常是包含关系：机器学习是人工智能的一个分支，深度学习是机器学习中使用多层神经网络的一类方法，生成式 AI 则通常建立在深度学习与大模型之上。范围越往里，技术越具体，但不代表“越高级”。规则系统在需要强审计的场景里，仍然可能比复杂模型更合适。</p>
          <p>另一个常见分类按能力范围划分：<strong>专用人工智能</strong>在特定任务上工作；<strong>通用人工智能</strong>是能够在广泛任务中达到或超过人类水平的理论目标；<strong>超级智能</strong>则属于更强的推测性概念。今天的系统在部分任务上表现突出，但仍不应被直接等同于通用人工智能。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>概念范围</span><span>越往里越具体</span></div>
            <div class="lp-stack">
              <div class="lp-stack-row lp-stack-row--1"><strong>人工智能 AI</strong><span>规则、搜索、规划、学习、生成等方法的集合</span></div>
              <div class="lp-stack-row lp-stack-row--2"><strong>机器学习 ML</strong><span>让系统从数据中学习模式</span></div>
              <div class="lp-stack-row lp-stack-row--3"><strong>深度学习 DL</strong><span>使用多层神经网络进行表示学习</span></div>
              <div class="lp-stack-row lp-stack-row--4"><strong>生成式 AI</strong><span>生成文本、图像、音频或视频</span></div>
            </div>
            <div class="lp-tagrow"><span>感知</span><span>预测</span><span>生成</span><span>决策</span><span>行动</span></div>
            <p class="lp-caption">包含关系是概念地图，不是能力高低排行榜。一个不生成内容的规则系统，也可以是 AI。</p>
          </div>
        """,
        "example": "手机语音助手会识别语音、理解意图、合成回答，通常属于专用人工智能；自动驾驶系统同时处理感知、预测与规划，能力很复杂，但仍在限定场景内工作。它们都不是“通用人工智能”。",
        "practice": {
            "question": "下列关于人工智能的说法，哪一项更准确？",
            "options": [
                ("A", "能够通过图灵测试的系统就已经是通用人工智能。"),
                ("B", "所有人工智能系统都必须依赖深度学习。"),
                ("C", "专用 AI 可以在特定任务上超过人类，但不具备广泛通用能力。"),
                ("D", "生成式 AI 已经具有人类意识与情感。"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>人工智能包括多种方法，专用 AI 在限定任务中可能表现很好，但这不等于具备跨领域的通用能力。图灵测试、生成能力或流畅对话都不能单独证明意识。</p>",
        },
        "takeaway": "AI 是一组方法的集合。判断一个系统时，先看任务、能力范围与限制，而不是只被名称吸引。",
        "resources": [
            ("教材框架与学习路径", "about.html#framework"),
            ("人工智能七十年", "article-ai-history.html"),
        ],
    },
    {
        "key": "p2-ai-history",
        "group": "基础与历史",
        "short": "七十年发展路径",
        "title": "七十年发展：从达特茅斯到生成式 AI",
        "chapter": "教材第 1 章 · 1.2—1.3",
        "minutes": 14,
        "tags": "历史 · 中国路径 · 技术周期",
        "dek": "人工智能不是一条持续上升的直线。理解符号主义、专家系统、两次寒冬与深度学习的兴起，才能理解今天的大模型为什么出现，又为什么仍然脆弱。",
        "body": """
          <h3>学科的命名与符号主义</h3>
          <p>1950 年，图灵在《计算机器与智能》中把“机器能思考吗”转化为一个可讨论的问题。1956 年达特茅斯会议让“人工智能”成为一个研究领域的名称。早期研究者相信，智能可以被表示为符号和推理规则，这条路径被称为符号主义。</p>
          <h3>技术热潮与寒冬</h3>
          <p>符号系统在规则明确的任务中有效，却难以处理真实世界的模糊性和常识。20 世纪 70 年代，过高的预期与有限的成果导致研究资源收缩。80 年代，专家系统带来商业化热潮，但知识维护成本高、规则难以覆盖边界情况，随后又出现低谷。</p>
          <p>两次寒冬给出的教训不是“ AI 没有价值”，而是：技术能力必须与数据、算力、应用场景和社会预期同时匹配，宏大叙事不能替代可验证的工程效果。</p>
          <h3>数据与算力驱动的转向</h3>
          <p>90 年代后，统计学习方法逐渐成为主流。2012 年，AlexNet 在图像识别任务中显著领先，深度学习进入主流视野；2017 年，Transformer 架构为大规模语言模型提供了关键基础；2022 年后，生成式对话模型进入公众应用。规模变大带来了新能力，也带来了幻觉、偏见与治理问题。</p>
          <h3>中国 AI 的路径</h3>
          <p>中国的人工智能研究从早期跟踪学习起步，在模式识别、机器翻译与专家系统等方向积累人才。1986 年启动的“863”计划将智能机器人等方向纳入高技术研究；互联网产业提供了丰富场景与数据；2017 年《新一代人工智能发展规划》将人工智能提升到国家战略层面。工程化与场景落地是优势，基础理论、算力与治理仍是长期课题。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>关键技术节点</span><span>不是完整年表</span></div>
            <ol class="lp-timeline">
              <li><time>1950</time><div><strong>图灵提出机器智能问题</strong><p>把哲学争论转化为可讨论的测试与问题。</p></div></li>
              <li><time>1956</time><div><strong>达特茅斯会议</strong><p>“人工智能”作为研究领域获得命名。</p></div></li>
              <li><time>1980s</time><div><strong>专家系统兴起</strong><p>知识工程商业化，也暴露维护与泛化瓶颈。</p></div></li>
              <li><time>2012</time><div><strong>AlexNet</strong><p>数据、GPU 与深度网络结合，深度学习成为主流。</p></div></li>
              <li><time>2017</time><div><strong>Transformer</strong><p>注意力机制为大模型与生成式 AI 奠基。</p></div></li>
              <li><time>2022</time><div><strong>生成式对话普及</strong><p>大模型进入日常应用，同时带来事实性与治理挑战。</p></div></li>
            </ol>
            <p class="lp-caption">技术史并非“每次新方法都取代旧方法”，而是方法、资源与场景不断重新组合。</p>
          </div>
        """,
        "example": "深蓝在 1997 年击败国际象棋世界冠军，主要依靠专用搜索与评估；今天的大语言模型则依靠大规模预训练与概率生成。两者都叫 AI，但技术路径、能力范围与错误方式完全不同。",
        "practice": {
            "question": "关于人工智能发展史，哪项判断更符合事实？",
            "options": [
                ("A", "技术发展是线性的，每一次新方法都会彻底淘汰旧方法。"),
                ("B", "专家系统的失败说明符号方法没有任何价值。"),
                ("C", "算法、数据、算力与场景共同影响技术周期，发展呈起伏而非直线。"),
                ("D", "生成式 AI 的出现意味着 AI 的所有安全问题已经解决。"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>历史上符号主义、统计学习与深度学习在不同阶段各自发挥作用。技术热度会起伏，但能力、资源与场景条件共同决定进展，新能力的出现也不会自动解决治理问题。</p>",
        },
        "takeaway": "把新技术放回历史周期中看：能力增长是真实的，但“这次一定不同”的叙事需要证据。",
        "resources": [
            ("完整文章：人工智能七十年", "article-ai-history.html"),
            ("教材框架与学习路径", "about.html#framework"),
        ],
    },
    {
        "key": "p3-ai-ethics",
        "group": "基础与历史",
        "short": "伦理与法律",
        "title": "伦理与法律：公平、透明、隐私与责任",
        "chapter": "教材第 2 章",
        "minutes": 12,
        "tags": "公平 · 透明 · 隐私 · 问责",
        "dek": "AI 进入招聘、信贷、医疗与司法之后，受影响的不再只是“用户体验”，而是人的机会、权利与尊严。伦理原则如何变成可执行的设计与制度？",
        "body": """
          <h3>伦理不是技术完成后的附加题</h3>
          <p>人工智能系统会参与资源分配与机会判断，因此它的设计目标、训练数据与使用方式都具有伦理后果。伦理关注“应该怎样做”，法律提供具有约束力的底线；两者相互补充，但不能互相替代。</p>
          <p>常见的核心原则包括：<strong>公平</strong>，避免不合理的差别对待；<strong>透明与可解释</strong>，让受影响者理解决定依据；<strong>隐私与数据治理</strong>，限制收集、使用与再识别；<strong>问责与人类监督</strong>，确保有人能够解释、纠错并承担后果。</p>
          <h3>算法偏见从哪里来</h3>
          <p>偏见并不只来自恶意代码。历史数据可能包含结构性不平等；目标函数可能优化了错误的东西；邮编、学校、消费记录等代理变量也可能间接编码身份。即使删除了性别或民族字段，模型仍可能通过其他特征“重建”这些差异。</p>
          <p>因此，公平不能只靠删除敏感字段，而需要检查不同群体的错误率与错误代价，评估模型在真实环境中的影响，并提供申诉和人工复核渠道。</p>
          <h3>透明、隐私与责任的具体含义</h3>
          <p>可解释性不是给出一张热力图就结束，而是让决定能够被理解、被质疑。隐私保护也不只是“不泄露”，还包括数据最小化、用途限制与拒绝画像。责任则需要明确开发者、部署者、使用者和管理者各自的义务，并保留日志与救济路径。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>四项设计检查</span><span>从原则到行动</span></div>
            <div class="lp-grid lp-grid--2">
              <div class="lp-card"><span class="lp-label">01 · 公平</span><strong>不同群体的错误代价是什么？</strong><p>不只看总体准确率，还要看谁被误判、谁承担后果。</p></div>
              <div class="lp-card"><span class="lp-label">02 · 透明</span><strong>受影响者能理解并质疑吗？</strong><p>说明用途、数据来源与限制，而不是只展示技术细节。</p></div>
              <div class="lp-card"><span class="lp-label">03 · 隐私</span><strong>真的需要这些数据吗？</strong><p>最小化收集，限制用途，防止通过组合数据再识别个人。</p></div>
              <div class="lp-card"><span class="lp-label">04 · 责任</span><strong>出错后谁负责、如何纠错？</strong><p>人类监督、审计日志、申诉渠道，缺一不可。</p></div>
            </div>
            <p class="lp-caption">原则的价值，在于能否转化为数据、界面、流程与责任制度中的具体约束。</p>
          </div>
        """,
        "example": "某招聘筛选系统移除了性别字段，但保留了“某类社团经历”作为重要特征。由于历史数据中男性更常拥有该经历，模型仍会系统性压低女性候选人的评分。删除一个字段，不能自动消除结构性偏差。",
        "practice": {
            "question": "一家银行希望减少信贷模型中的性别偏见。以下做法最不充分的是？",
            "options": [
                ("A", "删除性别字段，并直接假设偏见已经消失。"),
                ("B", "评估不同群体的通过率与错误代价。"),
                ("C", "检查邮编、职业等代理变量是否间接编码性别。"),
                ("D", "为被拒绝的申请人提供解释与人工复核渠道。"),
            ],
            "correct": "A",
            "explanation": "<p><strong>答案 A。</strong>删除显式字段是必要步骤，但不足以消除偏见。代理变量、历史数据与目标设定仍可能复制不平等。公平评估需要看不同群体的结果、错误代价和可用的救济机制。</p>",
        },
        "takeaway": "伦理原则要落在数据、目标、解释、监督与救济上；只删一个字段，通常不是治理。",
        "resources": [
            ("完整文章：AI 的社会影响", "article-ai-society.html"),
            ("全球 AI 治理框架", "article-ai-governance.html"),
        ],
    },
    {
        "key": "p4-machine-learning",
        "group": "技术原理",
        "short": "机器学习",
        "title": "机器学习：从数据中寻找规律",
        "chapter": "教材第 3 章",
        "minutes": 13,
        "tags": "监督学习 · 无监督学习 · 泛化",
        "dek": "机器学习不是把知识直接写进程序，而是让模型从样本中调整参数。理解学习信号与评估方式，才能判断一个模型“学会了”还是只“记住了”。",
        "body": """
          <h3>从数据到预测</h3>
          <p>机器学习用数据拟合输入与目标之间的关系。典型流程是：收集与清洗数据、提取特征、选择模型、定义损失函数、训练参数、在独立数据上评估，最后部署与监测。训练是调整参数的过程，推理则是用训练好的模型对新样本作出预测。</p>
          <h3>四种常见的学习信号</h3>
          <p><strong>监督学习</strong>使用带标签样本，例如“邮件—是否垃圾”；<strong>无监督学习</strong>没有标签，目标是发现结构，例如客户分群；<strong>自监督学习</strong>从数据自身构造预测任务，例如遮住一段文字让模型补全；<strong>强化学习</strong>通过奖励与惩罚学习策略，适合序列决策。大语言模型的预训练通常属于自监督式的“预测下一个 token”。</p>
          <h3>泛化与过拟合</h3>
          <p>模型在训练集上表现好，不代表在新数据上表现好。过拟合是记住了训练样本的噪声；分布变化则是训练环境与真实环境不一致。评估时需要使用独立验证集，并关注不同群体、不同场景下的错误，而不是只看一个总体准确率。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>四种学习范式</span><span>信号不同，问题不同</span></div>
            <div class="lp-grid lp-grid--4">
              <div class="lp-card"><span class="lp-label">Supervised</span><strong>监督学习</strong><p>有标签。分类、回归。例：垃圾邮件识别。</p></div>
              <div class="lp-card"><span class="lp-label">Unsupervised</span><strong>无监督学习</strong><p>无标签。聚类、降维。例：客户分群。</p></div>
              <div class="lp-card"><span class="lp-label">Self-supervised</span><strong>自监督学习</strong><p>从数据自身构造监督信号。例：预测被遮住的词。</p></div>
              <div class="lp-card"><span class="lp-label">Reinforcement</span><strong>强化学习</strong><p>通过奖励学习策略。例：游戏智能体。</p></div>
            </div>
            <div class="lp-flow lp-flow--compact">
              <span>数据</span><i class="lp-arrow" aria-hidden="true">→</i><span>特征与模型</span><i class="lp-arrow" aria-hidden="true">→</i><span>损失函数</span><i class="lp-arrow" aria-hidden="true">→</i><span>训练参数</span><i class="lp-arrow" aria-hidden="true">→</i><span>验证与部署</span>
            </div>
            <p class="lp-caption">机器学习的关键不是“让机器自己想”，而是设计合适的数据、目标、反馈与评估。</p>
          </div>
        """,
        "example": "电商平台把用户聚成若干群体，事先没有“高价值客户”等标签，这属于无监督聚类；如果想预测某个用户是否会流失，并且已有历史流失标签，则是监督学习。同一个业务问题可以选择不同范式，取决于你手上有什么信号。",
        "practice": {
            "question": "没有标签，希望把相似新闻自动归为一组。这最接近哪种学习范式？",
            "options": [
                ("A", "监督学习"),
                ("B", "无监督学习"),
                ("C", "强化学习"),
                ("D", "规则推理"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>没有标签、目标是发现数据内部结构的任务通常属于无监督学习，例如聚类。监督学习需要目标标签；强化学习依赖环境给出的奖励信号。</p>",
        },
        "takeaway": "先问数据里有什么信号，再选学习范式；先问模型在未见过的数据上表现如何，再谈效果。",
        "resources": [
            ("学习路径：从概念到实践", "project-learning.html"),
            ("论文专栏：基础模型", "articles.html#papers"),
        ],
    },
    {
        "key": "p5-deep-learning",
        "group": "技术原理",
        "short": "神经网络与深度学习",
        "title": "神经网络与深度学习：表示学习的力量",
        "chapter": "教材第 4 章",
        "minutes": 12,
        "tags": "神经网络 · 反向传播 · 表示学习",
        "dek": "深度学习之所以强大，不只是“层数多”，而是它能够从数据中逐层构造特征表示。理解这一点，才能理解它的能力来源与不可解释性。",
        "body": """
          <h3>从人工神经元到多层网络</h3>
          <p>人工神经元接收多个输入，乘以权重、求和后经过激活函数，产生输出。多个神经元组成层，层与层相连形成网络。如果没有非线性激活，多层网络仍然只能表达线性关系；非线性让网络能够逼近复杂的输入—输出映射。</p>
          <h3>反向传播与表示学习</h3>
          <p>训练时，网络先产生预测，再用损失函数衡量与目标之间的差距。反向传播计算损失对每个参数的梯度，优化器据此调整权重。所谓“深度”，指的是多层表示：在图像任务中，浅层可能学习边缘，中层学习纹理与部件，深层学习物体；在语言任务中，Transformer 的注意力让模型依据上下文动态组合信息。</p>
          <h3>能力来自数据、算力与架构的结合</h3>
          <p>深层网络并不是一个缩小的人脑。它的能力来自大规模数据、可并行计算的硬件、合适的网络结构以及训练方法。与此同时，参数规模巨大也带来了可解释性、评估与能耗问题。模型能做出准确预测，不自动意味着我们可以从参数中读出一套人类可理解的因果解释。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>一个简化的前馈网络</span><span>输入 → 隐藏层 → 输出</span></div>
            <svg class="lp-svg" viewBox="0 0 680 230" role="img" aria-labelledby="nnTitle nnDesc">
              <title id="nnTitle">简化的三层神经网络示意图</title>
              <desc id="nnDesc">四个输入节点经全连接连接到三个隐藏层节点，再连接到两个输出节点，展示逐层表示。</desc>
              <g stroke="#d5dfec" stroke-width="1.2">
                <path d="M110 48 L300 78 M110 48 L300 125 M110 48 L300 172 M110 93 L300 78 M110 93 L300 125 M110 93 L300 172 M110 138 L300 78 M110 138 L300 125 M110 138 L300 172 M110 183 L300 78 M110 183 L300 125 M110 183 L300 172 M300 78 L510 105 M300 78 L510 165 M300 125 L510 105 M300 125 L510 165 M300 172 L510 105 M300 172 L510 165"/>
              </g>
              <g fill="#fff" stroke="#1e4fd7" stroke-width="1.8">
                <circle cx="110" cy="48" r="14"/><circle cx="110" cy="93" r="14"/><circle cx="110" cy="138" r="14"/><circle cx="110" cy="183" r="14"/>
                <circle cx="300" cy="78" r="14"/><circle cx="300" cy="125" r="14"/><circle cx="300" cy="172" r="14"/>
                <circle cx="510" cy="105" r="14"/><circle cx="510" cy="165" r="14"/>
              </g>
              <g fill="#627188" font-size="11" font-family="Inter, PingFang SC, sans-serif" text-anchor="middle">
                <text x="110" y="222">输入层</text><text x="300" y="222">隐藏层 · 表示</text><text x="510" y="222">输出层</text>
                <text x="570" y="105">预测</text><text x="570" y="165">置信度</text>
              </g>
              <g fill="#1e4fd7" font-size="10" font-family="Inter, PingFang SC, sans-serif" text-anchor="middle">
                <text x="300" y="46">逐层组合特征</text>
              </g>
            </svg>
            <p class="lp-caption">每条连线是一个可学习参数。真实模型的规模远大于此，但“逐层变换—计算误差—反向调整”的基本逻辑相似。</p>
          </div>
        """,
        "example": "在人脸识别中，浅层网络可能对人脸边缘和明暗变化敏感，中层捕捉眼睛、鼻子等局部结构，深层把这些部件组合成身份特征。模型并没有被告知“这是眼睛”，这些表示是训练过程中逐渐形成的。",
        "practice": {
            "question": "在神经网络训练中，反向传播的主要作用是？",
            "options": [
                ("A", "把输入图片放大，以便网络看得更清楚。"),
                ("B", "根据损失函数计算的梯度，调整网络参数。"),
                ("C", "把模型参数随机删除，防止过拟合。"),
                ("D", "直接告诉模型每个神经元应该表示什么概念。"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>反向传播通过链式法则计算损失对参数的梯度，优化器再用这些梯度更新权重。网络内部表示大多不是人工指定的，而是训练中形成的。</p>",
        },
        "takeaway": "深度学习的核心是“可学习的多层表示”，而不是神秘智能。能力越强，越需要外部评估与可解释性工具。",
        "resources": [
            ("大模型的工作原理", "article-information-ecology.html#how-models-work"),
            ("论文专栏：Attention Is All You Need", "articles.html#papers"),
        ],
    },
    {
        "key": "p6-nlp",
        "group": "技术原理",
        "short": "自然语言处理",
        "title": "自然语言处理：机器如何理解语言",
        "chapter": "教材第 5 章",
        "minutes": 11,
        "tags": "词元 · 注意力 · 语境",
        "dek": "语言充满歧义、隐含意义与语境依赖。自然语言处理的任务，是把文本变成可计算的表示，再用上下文推断意义。",
        "body": """
          <h3>把语言变成数字</h3>
          <p>自然语言处理（NLP）研究机器如何理解、分析、转换和生成人类语言。流程通常从分词与词元化开始，把文本切成模型能处理的单位，再映射为向量表示。词向量不是人工写好的词典，而是从大量语料中学习出的数值坐标，相似语境中的词往往更接近。</p>
          <h3>注意力与上下文</h3>
          <p>同一个词在不同句子中可能意义不同。Transformer 的注意力机制会根据上下文，为序列中的不同词分配不同权重。例如在“苹果发布了新手机”和“我吃了一个苹果”中，“苹果”会与不同的词发生更强关联。模型据此形成上下文表示，再完成分类、翻译、问答或生成。</p>
          <h3>从任务指标到真实理解</h3>
          <p>NLP 模型在翻译、摘要和情感分类等任务上可以表现优秀，但依然可能在反讽、隐喻、文化背景和事实细节上出错。基准测试分数不能替代真实使用中的评估。语言流畅也不能证明模型理解了世界或核验了事实。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>一个 NLP 处理链</span><span>表示与上下文</span></div>
            <div class="lp-flow">
              <span>原始文本</span><i class="lp-arrow" aria-hidden="true">→</i><span>词元 / Token</span><i class="lp-arrow" aria-hidden="true">→</i><span>向量表示</span><i class="lp-arrow" aria-hidden="true">→</i><span>上下文与注意力</span><i class="lp-arrow" aria-hidden="true">→</i><span>分类 / 翻译 / 生成</span>
            </div>
            <div class="lp-compare">
              <div class="lp-compare-box"><span class="lp-label">语境 A</span><p>“苹果发布了新手机。”</p><small>“苹果”更接近公司、产品、发布会。</small></div>
              <div class="lp-compare-box"><span class="lp-label">语境 B</span><p>“我吃了一个苹果。”</p><small>“苹果”更接近水果、味道、食物。</small></div>
            </div>
            <p class="lp-caption">语言模型不是查固定词典，而是根据上下文动态形成表示。</p>
          </div>
        """,
        "example": "情感分类模型看到“这家餐厅环境很好，但等了两小时”，需要理解转折关系，不能只因为出现“很好”就给出正面评价。上下文与句法关系会改变最终判断。",
        "practice": {
            "question": "Transformer 中的注意力机制主要帮助模型做什么？",
            "options": [
                ("A", "根据上下文为不同词分配不同权重，建立语境表示。"),
                ("B", "把所有句子压缩成同一张固定词表。"),
                ("C", "保证生成内容一定符合事实。"),
                ("D", "替代所有人工标注数据。"),
            ],
            "correct": "A",
            "explanation": "<p><strong>答案 A。</strong>注意力机制让模型在处理某个位置的词时，动态参考序列中其他相关位置。它增强了上下文建模能力，但不能自动保证事实正确，也不能消除对数据与评估的依赖。</p>",
        },
        "takeaway": "NLP 的关键不是把语言变成词典，而是根据上下文动态表示意义；流畅生成与事实正确是两件事。",
        "resources": [
            ("长文：信息生态与大模型", "article-information-ecology.html#how-models-work"),
            ("文章：人工智能七十年", "article-ai-history.html"),
        ],
    },
    {
        "key": "p7-large-models",
        "group": "技术原理",
        "short": "大模型原理",
        "title": "大模型：下一词预测与能力边界",
        "chapter": "教材第 6 章",
        "minutes": 14,
        "tags": "预训练 · 生成 · 幻觉",
        "dek": "大语言模型的核心训练目标非常朴素：根据已有上下文预测下一个词元。规模带来了广泛能力，也带来了幻觉、知识过时与不可靠推理。",
        "body": """
          <h3>一句话概括生成机制</h3>
          <p>大语言模型（LLM）通常在海量文本上预训练，学习根据已有上下文预测下一个 token 的概率分布。生成时，模型一次预测一个 token，再把结果加入上下文，继续预测。所谓“写作”“翻译”与“问答”，都可以被统一到这种序列生成过程中。</p>
          <p>模型规模、数据规模与训练方法的提升，让这种统计预测表现出广泛的语言能力。但模型的目标是生成概率上合理的内容，不是独立核实事实。它没有天然的“我不知道”机制，也可能编造看似规范的引用。</p>
          <h3>预训练之后：微调、对齐与工具</h3>
          <p>预训练之后，研究者会通过指令微调、人类反馈对齐、安全训练等方式，让模型更符合任务与规范。检索增强生成（RAG）可以在生成前检索外部资料，工具调用可以接入计算器或数据库。这些方法能降低错误，但不能完全消除幻觉，因为最终输出仍需核验。</p>
          <h3>能力边界的四个关键词</h3>
          <p><strong>知识截止：</strong>模型不知道训练数据截止之后发生的变化；<strong>上下文窗口：</strong>一次能处理的文本有限；<strong>概率生成：</strong>同样的提示可能产生不同结果；<strong>缺乏事实保证：</strong>语言上的自信并不等于证据。理解这些边界，是把大模型用好的前提。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>下一词预测示意</span><span>概率为教学示意，并非真实模型输出</span></div>
            <p class="lp-demo-line">“人工智能正在改变我们的 <span>____</span>”</p>
            <div class="lp-bars">
              <div class="lp-bar-row"><span>生活</span><div class="lp-bar-track"><i style="width: 42%"></i></div><b>42%</b></div>
              <div class="lp-bar-row"><span>工作</span><div class="lp-bar-track"><i style="width: 28%"></i></div><b>28%</b></div>
              <div class="lp-bar-row"><span>学习方式</span><div class="lp-bar-track"><i style="width: 18%"></i></div><b>18%</b></div>
              <div class="lp-bar-row"><span>其他</span><div class="lp-bar-track"><i class="is-muted" style="width: 12%"></i></div><b>12%</b></div>
            </div>
            <div class="lp-flow lp-flow--compact">
              <span>上下文</span><i class="lp-arrow" aria-hidden="true">→</i><span>概率分布</span><i class="lp-arrow" aria-hidden="true">→</i><span>采样下一个词</span><i class="lp-arrow" aria-hidden="true">→</i><span>加入上下文，继续</span>
            </div>
            <p class="lp-caption">生成不是从数据库检索唯一答案，而是反复进行概率选择。温度等参数会改变输出的随机程度。</p>
          </div>
        """,
        "example": "一位学生让大模型推荐论文并生成引用。模型给出了作者、标题、年份和 DOI，格式非常规范；但数据库里根本不存在这篇论文。格式正确、语气肯定，都不能替代对原始文献的核验。",
        "practice": {
            "question": "大模型给出一个语气非常确定的错误答案。最合理的理解是？",
            "options": [
                ("A", "模型故意欺骗用户，因此它一定具备主观恶意。"),
                ("B", "只要答案语法正确，事实就应当被接受。"),
                ("C", "模型在生成概率上合理的内容，而不是经过事实核验的结论。"),
                ("D", "这只能说明用户的提示词写得不够长。"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>幻觉是生成式模型的系统性风险。模型可能生成流畅但缺乏事实依据的内容；提高提示质量、提供资料或使用工具可以降低风险，但仍需核验原始来源。</p>",
        },
        "takeaway": "大模型是强大的语言与模式工具，不是事实数据库。把“生成”与“确认”分开，是使用它的第一条规则。",
        "resources": [
            ("长文：生成式 AI 与信息生态", "article-information-ecology.html"),
            ("信息核查实验室", "experiment-verify.html"),
        ],
    },
    {
        "key": "p8-prompting",
        "group": "应用实践",
        "short": "提示与任务拆解",
        "title": "大模型协作：任务拆解与提示设计",
        "chapter": "教材第 7 章",
        "minutes": 12,
        "tags": "提示结构 · 迭代 · 核验",
        "dek": "提示词不是咒语。真正有效的协作，是把目标、上下文、约束与验收标准说清楚，并把大任务拆成可以核验的步骤。",
        "body": """
          <h3>从“帮我写”到可执行的任务</h3>
          <p>高质量提示通常包含五类信息：任务目标、背景上下文、目标读者、约束条件、输出格式。如果任务较复杂，还应说明步骤、示例与验收标准。模糊的提示会把关键决策留给模型，而模型并不了解你的真实意图。</p>
          <h3>先规划，再生成，再核验</h3>
          <p>与其让模型一次生成最终答案，不如让它先列提纲、指出需要补充的信息，再逐段完成。每一步都可以检查：引用是否存在、逻辑是否连贯、有没有遗漏反方观点。对需要事实的内容，要求给出可核查的来源，并自己回到原始资料确认。</p>
          <h3>边界与学术诚信</h3>
          <p>不要在提示中粘贴身份证、未公开的研究数据、他人隐私或商业机密。把 AI 当协作者，而不是匿名代写者：记录使用过程，说明哪些部分由 AI 辅助，保留最终的判断与责任。不同课程和机构对 AI 使用有不同规定，应按要求披露。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>一个可执行的提示结构</span><span>不是固定模板，而是检查清单</span></div>
            <div class="lp-prompt">
              <div class="lp-prompt-row"><span>任务</span><p>把一篇研究论文整理成面向同学的 5 分钟讲解稿。</p></div>
              <div class="lp-prompt-row"><span>上下文</span><p>听众是大一学生；已有材料见附录；不要补充未提供的结论。</p></div>
              <div class="lp-prompt-row"><span>约束</span><p>控制在 900 字以内；区分作者观点与你的总结；列出三个需要核验的事实。</p></div>
              <div class="lp-prompt-row"><span>输出</span><p>按“背景—问题—方法—结论—局限”分节，并给出一页提纲。</p></div>
            </div>
            <div class="lp-compare">
              <div class="lp-compare-box"><span class="lp-label">更模糊</span><p>“帮我写一篇关于 AI 的论文。”</p></div>
              <div class="lp-compare-box"><span class="lp-label">更可核验</span><p>“用以下三份资料，比较两种治理路径。先列提纲，再逐步写；每个关键判断附来源；最后列出你不确定的地方。”</p></div>
            </div>
          </div>
        """,
        "example": "准备课堂展示时，可以先让模型根据资料生成 5 个可能的讲解框架，你选择其一，再要求它指出每个框架需要补充的证据。这样模型帮助拓展思路，而选择与核验仍由你完成。",
        "practice": {
            "question": "以下哪个提示更有利于得到可核验、可修改的结果？",
            "options": [
                ("A", "“帮我写一篇完美的 AI 论文，越详细越好。”"),
                ("B", "“介绍一下人工智能。”"),
                ("C", "“面向非专业同学，用 800 字解释大模型幻觉；给出两个生活例子，并列出三个需要核验的事实。”"),
                ("D", "“不要问问题，直接给我最终答案。”"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>它明确了读者、篇幅、任务、示例与核验要求，便于检查与修改。过于模糊或要求一次给出“完美最终答案”的提示，会增加不可控与不可核验的风险。</p>",
        },
        "takeaway": "提示设计的核心不是“话术”，而是清晰表达任务与边界；让每一步都留下可检查的证据。",
        "resources": [
            ("学习路径：三阶段实践", "project-learning.html"),
            ("综合自测与答案", "answers.html"),
        ],
    },
    {
        "key": "p9-study-office",
        "group": "应用实践",
        "short": "学习与办公",
        "title": "AI 赋能学习与办公：效率不等于代替思考",
        "chapter": "教材第 8 章",
        "minutes": 11,
        "tags": "学习流程 · 信息保护 · 过程证据",
        "dek": "AI 可以加速摘要、头脑风暴、格式整理与代码辅助，但真正的学习与工作成果，仍需要目标、判断与责任。",
        "body": """
          <h3>把任务分成“可加速”和“不可外包”</h3>
          <p>适合交给 AI 辅助的任务包括：资料摘要、提纲生成、不同视角的头脑风暴、格式转换、初步代码与表格公式。不可外包的部分包括：确认事实、作出价值判断、保护他人隐私、承担最终责任，以及与人的沟通。</p>
          <h3>可信的学习循环</h3>
          <p>一个可复用的流程是：先自己明确问题，再让 AI 提供候选思路，随后回到原始资料核验，最后用自己的话重组并记录修改。不要让 AI 直接替你完成“理解”这一步，否则你得到的是一份成品，而不是能力。</p>
          <h3>办公场景中的数据边界</h3>
          <p>会议记录、合同、客户名单和内部代码可能包含敏感信息。在使用外部 AI 工具前，先确认组织政策与数据流向；必要时使用本地模型、脱敏数据或人工处理。效率不能成为绕过隐私与保密义务的理由。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>学习与办公的四步回路</span><span>人是判断与责任的中心</span></div>
            <div class="lp-flow">
              <span>自己定义任务</span><i class="lp-arrow" aria-hidden="true">→</i><span>AI 辅助发散</span><i class="lp-arrow" aria-hidden="true">→</i><span>核验原始资料</span><i class="lp-arrow" aria-hidden="true">→</i><span>重写与反思</span>
            </div>
            <div class="lp-grid lp-grid--2">
              <div class="lp-card"><span class="lp-label">AI 可以做</span><p>列提纲、找反例、解释术语、整理格式、生成初稿、给出练习建议。</p></div>
              <div class="lp-card"><span class="lp-label">必须由人做</span><p>核实事实、判断价值、保护隐私、决定是否发布、为结果负责。</p></div>
            </div>
          </div>
        """,
        "example": "写课程论文时，可以让 AI 根据你的阅读笔记生成一个比较框架，再自己回到论文原文核对每个观点。提交时附上 AI 使用记录：用了什么工具、哪些部分被修改、如何核验来源。这比假装完全没有使用更诚实，也更容易复盘。",
        "practice": {
            "question": "使用 AI 辅助课程作业时，下列哪种做法更符合学习目标与学术规范？",
            "options": [
                ("A", "直接提交 AI 生成的完整报告，不检查引用。"),
                ("B", "把老师的未公开讲义上传到公开 AI 工具，让它总结考点。"),
                ("C", "用 AI 生成提纲和初稿，自己核验资料、重写并按要求披露使用情况。"),
                ("D", "只要改几个词，就不需要说明 AI 的使用。"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>使用 AI 不等于违规，关键在透明、核验与学习投入。直接提交未核实的内容会带来事实与诚信风险；上传未公开材料则可能侵犯他人权益或违反规定。</p>",
        },
        "takeaway": "AI 可以缩短从想法到初稿的距离，但不能替代你走到理解、核验与负责的那一步。",
        "resources": [
            ("学习路径：任务与评价", "project-learning.html"),
            ("综合自测与答案", "answers.html"),
        ],
    },
    {
        "key": "p10-media",
        "group": "应用实践",
        "short": "多媒体创作",
        "title": "AI 多媒体创作：效率、版权与真实性",
        "chapter": "教材第 9 章",
        "minutes": 11,
        "tags": "图像生成 · 版权 · 标识",
        "dek": "生成图像、音频与视频工具正在改变创作流程。能力和便捷度提高之后，授权、知情与真实性反而变得更加重要。",
        "body": """
          <h3>从生成到编辑</h3>
          <p>图像生成模型通常学习大量图像与文本的对应关系，根据提示生成新的画面。它们可以用于草图、风格探索、背景与插画，也可以对已有素材进行局部编辑。音频与视频生成的能力也在发展，但生成结果的稳定性、可控性和版权状态仍需要具体判断。</p>
          <h3>三类不可忽略的边界</h3>
          <p><strong>版权与授权：</strong>不同平台、地区和作品类型的规则不同，不能假设“AI 生成”就等于“无版权”或“可自由商用”。<strong>人格与知情：</strong>未经许可，不应生成可识别的真实人物肖像、声音或误导性场景。<strong>真实性：</strong>如果作品用于新闻、证据或公共传播，必须明确标识合成来源，避免把合成画面当成事实记录。</p>
          <h3>一个负责的创作流程</h3>
          <p>明确用途 → 检查素材授权 → 生成与人工修改 → 记录工具与提示 → 标记合成内容 → 发布前评估影响。对于含有真实人物、品牌或敏感历史情境的内容，应更谨慎，并遵循平台与法律要求。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>多媒体创作流程</span><span>效率与责任并行</span></div>
            <div class="lp-flow">
              <span>用途与受众</span><i class="lp-arrow" aria-hidden="true">→</i><span>素材授权</span><i class="lp-arrow" aria-hidden="true">→</i><span>生成与编辑</span><i class="lp-arrow" aria-hidden="true">→</i><span>标识与披露</span><i class="lp-arrow" aria-hidden="true">→</i><span>发布前评估</span>
            </div>
            <div class="lp-tagrow">
              <span>版权状态</span><span>人物肖像</span><span>声音同意</span><span>合成标识</span><span>传播语境</span><span>平台规则</span>
            </div>
            <p class="lp-caption">“我做出来了”不是唯一的验收标准。能否说明来源、获得授权并让观众知情，同样重要。</p>
          </div>
        """,
        "example": "为社团制作活动海报时，可以用 AI 生成抽象背景与装饰图案；若海报需要出现指导老师的真实照片，应取得授权，而不是用其公开头像直接生成新表情或新场景。发布时注明使用了 AI 辅助创作。",
        "practice": {
            "question": "想用 AI 生成一张包含真实任课教师形象的活动宣传图。哪项做法更合适？",
            "options": [
                ("A", "直接使用教师社交媒体的公开头像生成，事后通知即可。"),
                ("B", "先获得教师对用途、形象与发布渠道的明确同意，再决定是否生成。"),
                ("C", "因为是校园活动，所以不需要考虑肖像与名誉问题。"),
                ("D", "只要在图片角落写“AI 生成”，就可以任意使用。"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>可识别的真实人物形象涉及肖像、人格与名誉等权益。用途、渠道与呈现方式都可能影响判断，应先取得明确同意；合成标识不能替代授权。</p>",
        },
        "takeaway": "生成能力越强，越需要把授权、知情与真实性写进创作流程，而不是发布后再补救。",
        "resources": [
            ("长文：信息生态与合成内容", "article-information-ecology.html"),
            ("实验：信息核查四步法", "experiment-verify.html"),
        ],
    },
    {
        "key": "p11-agents",
        "group": "应用实践",
        "short": "智能体",
        "title": "智能体：从回答问题到采取行动",
        "chapter": "教材第 10 章",
        "minutes": 12,
        "tags": "工具调用 · 权限 · 人类确认",
        "dek": "当大模型被允许调用工具、读写文件或执行操作，它就从“回答者”变成了“行动者”。能力扩展的同时，权限、错误传播与审计变得关键。",
        "body": """
          <h3>智能体不是一个更长的提示词</h3>
          <p>智能体通常由语言模型、任务规划、记忆、工具调用和执行权限组成。它可以根据目标拆解子任务，调用搜索、日历、代码执行或数据库接口，观察结果后继续行动。与普通聊天相比，智能体的关键区别是它能够改变外部状态。</p>
          <h3>循环与人类确认点</h3>
          <p>典型智能体循环是“观察—计划—行动—反馈”。每一轮行动都可能产生新信息，也可能引入错误。如果错误被后续步骤继续使用，风险会累积。因此，涉及付款、删除、发布、签署或对外发送的操作，应设置明确的人类确认点，并限制智能体可访问的工具与数据范围。</p>
          <h3>安全设计清单</h3>
          <p>采用最小权限、沙箱环境、操作日志与可撤销机制；不要向智能体暴露密钥或无关隐私；对提示注入保持警惕——网页或文档中的恶意指令可能诱导智能体偏离目标。把“能自动化”当作设计起点，而不是“应该自动化”的理由。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>智能体循环</span><span>每增加一次行动，就增加一个责任点</span></div>
            <div class="lp-flow">
              <span>目标</span><i class="lp-arrow" aria-hidden="true">→</i><span>计划</span><i class="lp-arrow" aria-hidden="true">→</i><span>调用工具</span><i class="lp-arrow" aria-hidden="true">→</i><span>观察结果</span><i class="lp-arrow" aria-hidden="true">→</i><span>调整 / 完成</span>
            </div>
            <div class="lp-gate">
              <span class="lp-label">Human check</span>
              <strong>不可逆操作必须暂停，交由人确认。</strong>
              <p>付款、发布、删除文件、共享隐私、签署协议、修改生产系统。</p>
            </div>
            <p class="lp-caption">评估智能体，不能只看“任务完成率”，还要看它出错时会造成什么后果、能否停下来。</p>
          </div>
        """,
        "example": "一个差旅智能体可以查询价格、整理行程并生成报销清单，但在最终付款或修改公司账户前，应把操作与金额展示给用户确认。若智能体拥有无限支付权限，一个小错误就可能变成真实损失。",
        "practice": {
            "question": "设计一个可以代订机票和酒店的智能体时，哪项安全设计最重要？",
            "options": [
                ("A", "给它管理员权限，减少每一步确认，让它更快完成任务。"),
                ("B", "允许它保存用户的支付密码，以便自动下单。"),
                ("C", "把支付、修改订单等不可逆操作设为需要用户明确确认。"),
                ("D", "只要模型足够大，就不需要日志和撤销机制。"),
            ],
            "correct": "C",
            "explanation": "<p><strong>答案 C。</strong>智能体会改变外部状态，必须最小化权限、记录操作并为高风险步骤设置人类确认。更大的模型并不能替代权限控制、审计与纠错机制。</p>",
        },
        "takeaway": "智能体的关键问题不是“它能不能做”，而是“它被允许做什么、如何确认、出错后怎样停下”。",
        "resources": [
            ("学习路径：任务拆解与风险", "project-learning.html"),
            ("AI 与司法中的自动化边界", "project-justice.html"),
        ],
    },
    {
        "key": "p12-justice",
        "group": "跨学科专题",
        "short": "AI 与司法",
        "title": "AI 与司法：辅助裁判，而非替代法官",
        "chapter": "教材第 2 章 · 拓展专题",
        "minutes": 13,
        "tags": "人机协同 · 程序正义 · 可解释",
        "dek": "AI 可以帮法官处理信息，却不能替代裁判说理与责任。效率、权利与程序正义之间，需要一套清晰的人机协同边界。",
        "body": """
          <h3>AI 在司法活动中的位置</h3>
          <p>在司法场景中，AI 可以用于电子卷宗整理、庭审语音转录、类案检索、文书格式校对、证据关系梳理与风险提示。这些应用可能降低检索成本、减少重复劳动，也能帮助发现被忽略的材料。越接近最终裁判，技术介入的要求就越高。</p>
          <h3>为什么不能“自动判决”</h3>
          <p>司法裁判不仅是对事实的分类，也包含证据采信、法律解释、价值权衡与说理。算法风险包括自动化偏见、数据偏差、不可解释性与责任模糊。当事人有权知道影响其权利的决定如何作出，并拥有异议与救济的机会。把这些环节自动化，可能侵蚀程序正义。</p>
          <h3>可执行的人机协同底线</h3>
          <p>人类法官保留最终决定权；AI 的用途与输出应可追溯；高风险场景要有人工复核与审计日志；不得将风险评分直接等同于事实结论；当事人应有知情与异议渠道。技术可以提高效率，但效率不能替代正义。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>人机协同工作流</span><span>人类判断始终在回路中</span></div>
            <div class="lp-flow">
              <span>案件进入</span><i class="lp-arrow" aria-hidden="true">→</i><span>AI 检索与整理</span><i class="lp-arrow" aria-hidden="true">→</i><span>法官独立审查</span><i class="lp-arrow" aria-hidden="true">→</i><span>说理与记录</span><i class="lp-arrow" aria-hidden="true">→</i><span>救济与监督</span>
            </div>
            <div class="lp-grid lp-grid--3">
              <div class="lp-card"><span class="lp-label">可以辅助</span><p>检索、转录、摘要、格式校对。</p></div>
              <div class="lp-card"><span class="lp-label">必须谨慎</span><p>证据关联、风险评估、量刑参考。</p></div>
              <div class="lp-card"><span class="lp-label">不可让渡</span><p>事实认定、法律解释、裁判说理与责任。</p></div>
            </div>
          </div>
        """,
        "example": "某量刑辅助系统给出“高再犯风险”的分数。这个分数只能作为提醒，不能自动成为从重量刑的依据。法官仍需审查数据来源、评估局限、案件具体情节与当事人陈述，并把理由写入裁判文书。",
        "practice": {
            "question": "在司法场景中使用 AI，哪项原则最为关键？",
            "options": [
                ("A", "只要模型准确率高于人类，就可以自动作出最终裁判。"),
                ("B", "AI 可以辅助检索与整理，但人类必须保留独立裁判、说理与纠错责任。"),
                ("C", "AI 的使用无需告知当事人，以免影响效率。"),
                ("D", "风险评分可以替代对证据的独立审查。"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>司法裁判涉及证据、法律与价值判断，必须保留人类的最终决定权与说理义务。技术可以辅助，但不能让责任消失在系统之中。</p>",
        },
        "takeaway": "在司法中，AI 的正当性不只取决于准确率，还取决于程序能否被看见、被质疑与被救济。",
        "resources": [
            ("项目：AI 与司法实践", "project-justice.html"),
            ("文章：全球 AI 治理", "article-ai-governance.html"),
        ],
    },
    {
        "key": "p13-information",
        "group": "跨学科专题",
        "short": "信息生态",
        "title": "生成式 AI 与信息生态：核查先于相信",
        "chapter": "教材第 6—7 章 · 拓展专题",
        "minutes": 12,
        "tags": "幻觉 · 深度伪造 · 核查",
        "dek": "当生成内容的成本接近零，信息环境最稀缺的资源变成了确认。面对合成内容，直觉与检测工具都不够，需要一套可重复的核查流程。",
        "body": """
          <h3>内容生产链被重写</h3>
          <p>生成式 AI 降低了文本、图像与音视频的生产成本，也让内容可以被批量改写、重组与分发。信息更多不等于理解更多；当每个人都可能进入定制的信息微环境，公共事实与注意力都会承受压力。</p>
          <h3>四种风险叠加</h3>
          <p><strong>幻觉</strong>是生成看似合理但缺乏事实依据的内容；<strong>深度伪造</strong>制造逼真的合成人物与场景；<strong>低质内容扩张</strong>用批量生成占据搜索与推荐；<strong>认知操纵</strong>则通过情绪化叙事与选择性呈现放大偏见。它们往往同时发生。</p>
          <h3>四步核查</h3>
          <p>第一步，停一下，识别情绪钩子；第二步，寻找最早发布者、时间与完整语境；第三步，横向打开独立信源，而不是只看同一张图的转载；第四步，区分“未证实”与“已证伪”。标识、内容凭证与平台治理能提供帮助，但个人仍需要保留判断。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>核查四步法</span><span>把怀疑变成动作</span></div>
            <div class="lp-flow">
              <span>停一下</span><i class="lp-arrow" aria-hidden="true">→</i><span>找来源</span><i class="lp-arrow" aria-hidden="true">→</i><span>横向比较</span><i class="lp-arrow" aria-hidden="true">→</i><span>保留不确定</span>
            </div>
            <div class="lp-grid lp-grid--2">
              <div class="lp-card"><span class="lp-label">先问</span><p>这条内容希望我产生什么情绪？它最早出现在哪里？</p></div>
              <div class="lp-card"><span class="lp-label">再查</span><p>有没有独立信源？原始文件、时间与地点能否对上？</p></div>
            </div>
            <p class="lp-caption">检测工具只能提供信号。合成与检测是持续博弈，来源与语境往往更可靠。</p>
          </div>
        """,
        "example": "一张“今天暴雨”的照片被大量转发，但通过反向图片搜索可以发现，它三年前曾在另一个城市出现。即使照片本身没有被 AI 篡改，“时间与地点错位”也足以让它成为误导信息。",
        "practice": {
            "question": "看到一张引发强烈情绪、被大量转发的“现场照片”，第一步最合理的做法是？",
            "options": [
                ("A", "立刻转发提醒亲友，以免错过重要信息。"),
                ("B", "先找最早发布来源、发布时间与原始语境，并横向查找独立信源。"),
                ("C", "只看评论区是否有很多人相信。"),
                ("D", "用肉眼判断有没有 AI 生成痕迹，看不出就认定真实。"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>情绪强度与转发量都不是真实性证据。先追溯最早来源与语境，再做横向比较，能够发现旧图新用、地点错置或断章取义等问题。</p>",
        },
        "takeaway": "在生成式 AI 时代，信息素养不是“知道更多”，而是知道如何确认、何时保留不确定。",
        "resources": [
            ("长文：生成式 AI 与信息生态", "article-information-ecology.html"),
            ("项目：信息生态与核查路径", "project-ecology.html"),
        ],
    },
    {
        "key": "p14-governance",
        "group": "跨学科专题",
        "short": "全球 AI 治理",
        "title": "全球 AI 治理：原则如何成为规则",
        "chapter": "教材第 2 章 · 拓展专题",
        "minutes": 13,
        "tags": "风险分级 · 敏捷治理 · 国际合作",
        "dek": "人工智能的风险跨越国界，规则却仍主要由主权国家制定。理解不同路径背后的价值排序，比简单比较“谁更先进”更重要。",
        "body": """
          <h3>为什么治理无法只靠企业自律</h3>
          <p>AI 具有通用性，同一个模型可以用于医疗、教育、金融，也可以用于监控与欺诈。风险往往不可见、难以归因，且会随部署规模放大。治理需要明确谁有权监管、谁承担责任、受影响者如何获得解释与救济。</p>
          <h3>三种主要路径</h3>
          <p><strong>欧盟</strong>采取横向立法与风险分级，对高风险系统提出数据治理、透明度与人工监督要求；<strong>中国</strong>强调发展与安全并重，通过算法推荐、深度合成、生成式服务与内容标识等场景化规则进行敏捷治理；<strong>美国</strong>更多依赖部门规则、行业自律与州层立法。国际组织则通过原则、评估与能力建设提供合作框架。</p>
          <h3>共同难题</h3>
          <p>模型跨境部署、开源模型责任、算力分配、评估标准互认与全球南方能力建设，都还没有简单答案。比较治理路径时，应同时看制度目标、执行能力与权利保障，而不是把某一种模式当成普遍模板。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>同题不同答</span><span>治理路径与制度约束</span></div>
            <div class="lp-table-wrap">
              <table class="lp-table">
                <thead><tr><th>维度</th><th>欧盟</th><th>中国</th><th>美国</th></tr></thead>
                <tbody>
                  <tr><td>主要工具</td><td>综合立法 · 风险分级</td><td>场景规则 · 敏捷治理</td><td>部门规则 · 行业自律</td></tr>
                  <tr><td>核心目标</td><td>基本权利与单一市场</td><td>发展、安全与可控</td><td>创新与国家安全</td></tr>
                  <tr><td>合规重点</td><td>风险管理、透明度</td><td>备案、标识、主体责任</td><td>部门权限、消费者保护</td></tr>
                </tbody>
              </table>
            </div>
            <p class="lp-caption">这不是“谁更先进”的排名，而是不同政治结构、法律传统与产业位置下的制度选择。</p>
          </div>
        """,
        "example": "生成式 AI 合成内容在中国受到标识制度约束，欧盟《人工智能法案》则对深度合成内容设置透明度义务。具体条文、生效时间与适用范围会变化，引用时应核对官方最新文本。",
        "practice": {
            "question": "欧盟《人工智能法案》的主要监管思路是？",
            "options": [
                ("A", "禁止所有人工智能应用。"),
                ("B", "按风险等级配置差异化义务，对高风险系统提出更严格要求。"),
                ("C", "只监管聊天机器人，不涉及通用模型。"),
                ("D", "完全依赖企业自愿承诺。"),
            ],
            "correct": "B",
            "explanation": "<p><strong>答案 B。</strong>欧盟采取横向立法与风险分级思路，禁止不可接受风险的应用，并对高风险系统与通用模型设置分层义务。具体实施仍在分阶段推进。</p>",
        },
        "takeaway": "治理不是创新的对立面。清晰的责任、评估与救济，能够降低风险，也为长期创新提供稳定预期。",
        "resources": [
            ("长文：全球 AI 治理", "article-ai-governance.html"),
            ("项目：AI 与司法的人机协同", "project-justice.html"),
        ],
    },
    {
        "key": "p15-literacy",
        "group": "素养与行动",
        "short": "AI 素养",
        "title": "AI 素养：把判断力留在回路中",
        "chapter": "教材第 1、2 章 · 综合",
        "minutes": 10,
        "tags": "知识 · 技能 · 价值",
        "dek": "会使用工具只是起点。真正的 AI 素养，是在理解能力与边界的基础上，核验信息、保护他人、说明使用并承担后果。",
        "body": """
          <h3>AI 素养的三层结构</h3>
          <p><strong>知识</strong>：理解 AI、机器学习与大模型的基本原理，知道能力与局限；<strong>技能</strong>：能拆解任务、设计提示、核验来源、保护数据、记录过程；<strong>价值</strong>：愿意为使用方式负责，并能讨论公平、隐私、权利与公共善。</p>
          <h3>五个可操作的习惯</h3>
          <p>先核实，再引用；不输入敏感信息；对 AI 参与的部分作必要披露；在不可逆或高影响决策中保留人类确认；持续记录“我用了什么、如何验证、最后为什么这样判断”。</p>
          <h3>面对快速变化的工具</h3>
          <p>具体产品会不断更新，真正可迁移的是判断框架：这段输出是否有证据？谁可能受到影响？我是否理解了任务？出错时能否纠错？把这些问题带进学习、工作与公共讨论，比追逐下一个“万能提示词”更重要。</p>
        """,
        "visual": """
          <div class="lesson-visual">
            <div class="lp-head"><span>AI 素养的三层结构</span><span>从会用到会判断</span></div>
            <div class="lp-pyramid">
              <div class="lp-pyramid-row lp-pyramid-row--top"><strong>价值</strong><span>责任 · 公平 · 隐私 · 公共善</span></div>
              <div class="lp-pyramid-row lp-pyramid-row--mid"><strong>技能</strong><span>核验 · 提问 · 保护 · 记录 · 纠错</span></div>
              <div class="lp-pyramid-row lp-pyramid-row--base"><strong>知识</strong><span>原理 · 能力边界 · 技术与社会</span></div>
            </div>
            <div class="lp-tagrow"><span>先核实</span><span>不泄露</span><span>作披露</span><span>留人类判断</span><span>会复盘</span></div>
          </div>
        """,
        "example": "完成小组项目时，团队建立了 AI 使用日志：谁在什么环节使用了模型、提示了什么、哪些输出被采纳、关键事实由谁核验、最终如何修改。这样既提高效率，也能在答辩时清楚说明工作过程。",
        "practice": {
            "question": "以下哪种行为最能体现完整的 AI 素养？",
            "options": [
                ("A", "记住最多提示词模板，追求一次性生成完美答案。"),
                ("B", "只要能生成，就先发布，出现问题再删除。"),
                ("C", "把 AI 输出当作权威结论，以节省查资料时间。"),
                ("D", "理解工具边界，核验信息、保护隐私、披露使用并对最终结果负责。"),
            ],
            "correct": "D",
            "explanation": "<p><strong>答案 D。</strong>AI 素养包含知识、技能与价值三个层面。仅会写提示词不够；能否核验、保护他人、透明使用并承担责任，才是可持续的能力。</p>",
        },
        "takeaway": "把判断力留在回路中：AI 可以加速行动，但理解、核验与责任仍然属于人。",
        "resources": [
            ("综合自测：12 道题与答案解析", "answers.html"),
            ("学习路径：三阶段 AI 通识", "project-learning.html"),
        ],
    },
]
